package com.Jpet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page2 {
	 WebDriver wd;



	   public void init_pagetest_2(WebDriver wd) {
	        this.wd = wd;
	    }



	   public void open_signin_page() {
	        WebElement signin = wd.findElement(By.xpath("/html/body/div[1]/div[2]/div/a[2]"));
	        signin.click();
	    }

}
