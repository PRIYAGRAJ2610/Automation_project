package com.Jpet;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page3 {

	
	WebDriver wd;
    FileReader fr;
    Properties p=new Properties();
    
    By user= By.xpath("/html/body/div[2]/div/form/p[2]/input[1]");
    By pass= By.xpath("/html/body/div[2]/div/form/p[2]/input[2]");
    By submit= By.xpath("/html/body/div[2]/div/form/input");
    
    public void initpagetest1(WebDriver wd) {
        this.wd = wd;
    }
    
    public void fun_enter_username() throws IOException {
        fr=new FileReader(".//TestCases//testcases.properties");
        p.load(fr);
        wd.findElement(user).clear();
        wd.findElement(user).sendKeys(p.getProperty("username"));
    }
    
    public void fun_enter_password() throws IOException, InterruptedException {
        fr=new FileReader(".//TestCases//testcases.properties");
        p.load(fr);
        wd.findElement(pass).clear();
        Thread.sleep(2000) ;
        wd.findElement(pass).sendKeys(p.getProperty("password"));
    }
    
    public void fun_click_submit() throws IOException {
        wd.findElement(submit).click();
    }
}
