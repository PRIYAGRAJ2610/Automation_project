package TrainingAtSOlera_QAA_Banglore_oct22_Framework.trainig01;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.Jpet.Page1;
import com.Jpet.Page2;
import com.Jpet.Page3;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.TestCase;

//import junit.framework.Test;
//import junit.framework.TestCase;
//import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
   
{

    WebDriver wd;



   Page1 p1 = new Page1();
    Page2 p2 = new Page2();
    Page3 p3 = new Page3() ;
//    Page4 p4 = new Page4() ;

    static ExtentTest test2;
    static ExtentReports rep2;
    String browser = "firefox" ;
   @BeforeTest
    public void driverPathSet() {
	   
	   if(browser.equals("chrome")) {
		   
		   System.setProperty("webdriver.chrome.driver", ".//Drivers//chromedriver.exe");
	        wd = new ChromeDriver();
		   
	   }
	   else if(browser.equals("firefox")) {
		   System.setProperty("webdriver.gecko.driver", ".//Drivers//geckodriver.exe");
	        wd = new FirefoxDriver();
		   
		   
	   }
       
        
        rep2=new ExtentReports(System.getProperty("user.dir")
                + "./Reports/reports.html");
        test2=rep2.startTest("AppTest");
    }
      
    
    
  
      
    



   @org.testng.annotations.Test(priority = 1)
    public void launch() throws InterruptedException {
        Thread.sleep(2000);
        p1.init_pagetest_1(wd);
        p1.launch_app_pt1();
        test2.log(LogStatus.PASS, "User has successfully launched the application");
    }



   @org.testng.annotations.Test(priority = 2)
    public void launch_store() throws InterruptedException {
        Thread.sleep(2000);
        p1.enter_store();
        test2.log(LogStatus.PASS, "User has entered the store");
    }



   @org.testng.annotations.Test(priority = 3)
    public void signin_store() throws InterruptedException {
        Thread.sleep(2000);
        p2.init_pagetest_2(wd);
        p2.open_signin_page();
        test2.log(LogStatus.PASS, "User has loggedin into the account");
    }
   @org.testng.annotations.Test(priority = 4)
   public void usernameinput() throws InterruptedException, IOException {
	   Thread.sleep(2000);
	   p3.initpagetest1(wd);
	   p3.fun_enter_username();
	   p3.fun_enter_password();
	   p3.fun_click_submit();
	   File src = ((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
       Files.copy(src, new File("./Screenimage/TC001Err.png"));
	   
	   
	   
   }
   
//   
//   @org.testng.annotations.Test(priority = 5)
//   public void ss() throws IOException
//   {
//	   p4.loginValidation();
//	   
//	   
//   }
   
   
   @AfterTest
   public void endmethod() {
	
	      rep2.endTest(test2);
	      rep2.flush();
	      rep2.close();
	   
	   
   }
   
   
}
